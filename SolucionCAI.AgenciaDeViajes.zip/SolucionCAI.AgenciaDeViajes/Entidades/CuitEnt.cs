﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolucionCAI.AgenciaDeViajes.Entidades
{
    public class CuitEnt
    {
        public int Prefijo { get; set; }
        public int NumSoc { get; set; }
        public int Sufijo { get; set; }
    }
}
