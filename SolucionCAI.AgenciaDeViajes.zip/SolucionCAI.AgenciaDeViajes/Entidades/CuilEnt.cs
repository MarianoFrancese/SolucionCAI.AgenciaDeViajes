﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolucionCAI.AgenciaDeViajes.Entidades
{
    public class CuilEnt
    {
        public int Prefijo { get; set; }
        public int DNI { get; set; }
        public int Sufijo { get; set; }
    }
}
