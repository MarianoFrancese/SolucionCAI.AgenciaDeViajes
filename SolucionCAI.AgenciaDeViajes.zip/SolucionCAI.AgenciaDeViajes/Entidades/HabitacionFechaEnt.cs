﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolucionCAI.AgenciaDeViajes.Entidades
{
    public class HabitacionFechaEnt
    {
        public DateTime FechaEntHab { get; set; }
        public DateTime FechaSalHab { get; set; }
        public int CantHab { get; set; }
    }
}
